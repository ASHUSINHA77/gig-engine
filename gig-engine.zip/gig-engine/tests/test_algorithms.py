"""
Unit tests for the pure algorithmic pipeline in app/algorithms.py.

No database, no HTTP — pure function testing.
"""

from __future__ import annotations

import math

import pytest

from app.algorithms import compound_score, find_best_worker, haversine, rank_all_workers
from app.models import Worker, WorkerStatus


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_worker(
    *,
    worker_id: str,
    name: str,
    lat: float,
    lon: float,
    rating: float,
    status: WorkerStatus = WorkerStatus.available,
) -> Worker:
    w = Worker()
    w.id = worker_id
    w.name = name
    w.latitude = lat
    w.longitude = lon
    w.skill_rating = rating
    w.status = status
    return w


# ---------------------------------------------------------------------------
# Haversine tests
# ---------------------------------------------------------------------------


class TestHaversine:
    def test_same_point_is_zero(self):
        assert haversine(0.0, 0.0, 0.0, 0.0) == pytest.approx(0.0, abs=1e-9)

    def test_known_distance_bangalore_to_mumbai(self):
        # Bangalore (12.9716, 77.5946) → Mumbai (19.0760, 72.8777)
        # Haversine gives ~845 km (±5 km tolerance)
        dist = haversine(12.9716, 77.5946, 19.0760, 72.8777)
        assert 840 < dist < 855, f"Expected ~845 km, got {dist:.2f} km"

    def test_known_distance_equatorial_degree(self):
        # 1 degree of longitude along the equator ≈ 111.32 km
        dist = haversine(0.0, 0.0, 0.0, 1.0)
        assert dist == pytest.approx(111.32, abs=0.5)

    def test_symmetry(self):
        a, b = (28.6139, 77.2090), (19.0760, 72.8777)   # Delhi → Mumbai
        assert haversine(*a, *b) == pytest.approx(haversine(*b, *a), rel=1e-10)

    def test_returns_float(self):
        result = haversine(12.0, 77.0, 13.0, 78.0)
        assert isinstance(result, float)

    def test_antipodal_points(self):
        # Diametrically opposite points should be ~20_015 km apart
        dist = haversine(0.0, 0.0, 0.0, 180.0)
        assert dist == pytest.approx(20_015.09, abs=1.0)


# ---------------------------------------------------------------------------
# Compound score tests
# ---------------------------------------------------------------------------


class TestCompoundScore:
    def test_perfect_worker(self):
        # Distance 0, max rating → score should be 0
        score = compound_score(0.0, 10.0, max_distance_km=100.0, max_rating=10.0)
        assert score == pytest.approx(0.0, abs=1e-9)

    def test_worst_worker(self):
        # Max distance, zero rating → score approaches 1.0 (0.6 * 1 + 0.4 * 1)
        score = compound_score(100.0, 0.0, max_distance_km=100.0, max_rating=10.0)
        assert score == pytest.approx(1.0, abs=1e-9)

    def test_distance_dominates_at_same_rating(self):
        near = compound_score(10.0, 7.0, max_distance_km=100.0, max_rating=10.0)
        far = compound_score(80.0, 7.0, max_distance_km=100.0, max_rating=10.0)
        assert near < far

    def test_rating_matters_at_same_distance(self):
        high_skill = compound_score(50.0, 9.0, max_distance_km=100.0, max_rating=10.0)
        low_skill = compound_score(50.0, 3.0, max_distance_km=100.0, max_rating=10.0)
        assert high_skill < low_skill

    def test_beyond_max_distance_capped(self):
        # Worker 200 km away should not score worse than 600 km — both capped at 1.0
        s200 = compound_score(200.0, 5.0, max_distance_km=100.0)
        s600 = compound_score(600.0, 5.0, max_distance_km=100.0)
        assert s200 == pytest.approx(s600, abs=1e-9)

    def test_weight_sum_flexibility(self):
        # Custom weights
        score = compound_score(
            50.0, 5.0,
            max_distance_km=100.0, max_rating=10.0,
            distance_weight=0.5, rating_weight=0.5,
        )
        expected = 0.5 * (50 / 100) + 0.5 * (1 - 5 / 10)
        assert score == pytest.approx(expected, rel=1e-9)


# ---------------------------------------------------------------------------
# find_best_worker tests
# ---------------------------------------------------------------------------


class TestFindBestWorker:
    # Task location: Koramangala, Bangalore
    TASK_LAT, TASK_LON = 12.9352, 77.6245
    MIN_RATING = 6.0

    def _w(self, wid, lat, lon, rating, status=WorkerStatus.available):
        return make_worker(worker_id=wid, name=f"Worker-{wid}", lat=lat, lon=lon,
                           rating=rating, status=status)

    def test_returns_none_when_no_workers(self):
        match, count = find_best_worker(self.TASK_LAT, self.TASK_LON, self.MIN_RATING, [])
        assert match is None
        assert count == 0

    def test_returns_none_when_all_below_min_rating(self):
        workers = [self._w("w1", 12.93, 77.62, 4.0)]
        match, count = find_best_worker(self.TASK_LAT, self.TASK_LON, self.MIN_RATING, workers)
        assert match is None
        assert count == 0

    def test_returns_none_when_all_busy(self):
        workers = [self._w("w1", 12.93, 77.62, 8.0, WorkerStatus.busy)]
        match, count = find_best_worker(self.TASK_LAT, self.TASK_LON, self.MIN_RATING, workers)
        assert match is None
        assert count == 0

    def test_single_eligible_worker_returned(self):
        workers = [self._w("w1", 12.93, 77.62, 7.0)]
        match, count = find_best_worker(self.TASK_LAT, self.TASK_LON, self.MIN_RATING, workers)
        assert match is not None
        assert match.worker.id == "w1"
        assert count == 1

    def test_nearest_worker_wins_at_equal_rating(self):
        near = self._w("near", 12.9360, 77.6250, 8.0)   # very close
        far  = self._w("far",  13.1000, 77.8000, 8.0)   # ~25 km away
        match, _ = find_best_worker(self.TASK_LAT, self.TASK_LON, self.MIN_RATING, [near, far])
        assert match is not None
        assert match.worker.id == "near"

    def test_higher_skill_can_beat_slightly_closer_worker(self):
        # w_close has slightly lower rating; w_skilled is a bit farther but much higher rated.
        # At default weights (60% dist, 40% rating) the skilled worker can win if the
        # distance delta is small and the rating delta is large.
        w_close   = self._w("close",   12.9355, 77.6248, 6.1)   # ~35 m away, barely qualifies
        w_skilled = self._w("skilled", 12.9370, 77.6260, 10.0)  # ~300 m away, max rating

        dist_close   = haversine(self.TASK_LAT, self.TASK_LON, w_close.latitude,   w_close.longitude)
        dist_skilled = haversine(self.TASK_LAT, self.TASK_LON, w_skilled.latitude, w_skilled.longitude)

        score_close   = compound_score(dist_close,   w_close.skill_rating)
        score_skilled = compound_score(dist_skilled, w_skilled.skill_rating)

        expected_winner = "close" if score_close < score_skilled else "skilled"

        match, _ = find_best_worker(
            self.TASK_LAT, self.TASK_LON, self.MIN_RATING, [w_close, w_skilled]
        )
        assert match is not None
        assert match.worker.id == expected_winner

    def test_candidates_evaluated_count(self):
        workers = [
            self._w("w1", 12.93, 77.62, 4.0),           # filtered — below min rating
            self._w("w2", 12.93, 77.62, 8.0, WorkerStatus.busy),  # filtered — busy
            self._w("w3", 12.93, 77.62, 7.5),            # eligible
            self._w("w4", 12.94, 77.63, 9.0),            # eligible
        ]
        _, count = find_best_worker(self.TASK_LAT, self.TASK_LON, self.MIN_RATING, workers)
        assert count == 2   # only w3 and w4 passed all filters

    def test_match_has_positive_distance(self):
        workers = [self._w("w1", 13.0000, 77.7000, 8.0)]
        match, _ = find_best_worker(self.TASK_LAT, self.TASK_LON, self.MIN_RATING, workers)
        assert match is not None
        assert match.distance_km > 0

    def test_match_score_in_valid_range(self):
        workers = [self._w("w1", 12.94, 77.63, 7.0)]
        match, _ = find_best_worker(self.TASK_LAT, self.TASK_LON, self.MIN_RATING, workers)
        assert match is not None
        assert 0.0 <= match.score <= 1.5   # upper bound is loose; cap protects it


# ---------------------------------------------------------------------------
# rank_all_workers tests
# ---------------------------------------------------------------------------


class TestRankAllWorkers:
    TASK_LAT, TASK_LON = 12.9352, 77.6245

    def _w(self, wid, lat, lon, rating, status=WorkerStatus.available):
        return make_worker(worker_id=wid, name=f"Worker-{wid}", lat=lat, lon=lon,
                           rating=rating, status=status)

    def test_empty_returns_empty_list(self):
        assert rank_all_workers(self.TASK_LAT, self.TASK_LON, 5.0, []) == []

    def test_result_is_sorted_ascending(self):
        workers = [
            self._w("a", 12.94, 77.63, 9.0),
            self._w("b", 13.10, 77.80, 9.0),
            self._w("c", 12.93, 77.62, 9.0),
        ]
        ranked = rank_all_workers(self.TASK_LAT, self.TASK_LON, 6.0, workers)
        scores = [r.score for r in ranked]
        assert scores == sorted(scores)

    def test_ineligible_workers_excluded(self):
        workers = [
            self._w("ok",  12.93, 77.62, 8.0),
            self._w("bad", 12.93, 77.62, 3.0),  # below min rating
        ]
        ranked = rank_all_workers(self.TASK_LAT, self.TASK_LON, 6.0, workers)
        ids = [r.worker.id for r in ranked]
        assert "ok" in ids
        assert "bad" not in ids
