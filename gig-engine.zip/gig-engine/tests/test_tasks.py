"""
Integration tests for the /api/tasks endpoints including the matching pipeline.
"""

from __future__ import annotations

import pytest
from httpx import AsyncClient

pytestmark = pytest.mark.asyncio

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _create_worker(
    client: AsyncClient,
    *,
    name: str,
    lat: float,
    lon: float,
    rating: float,
    status: str = "Available",
) -> dict:
    resp = await client.post(
        "/api/workers",
        json={
            "name": name,
            "latitude": lat,
            "longitude": lon,
            "skill_rating": rating,
            "status": status,
        },
    )
    assert resp.status_code == 201
    return resp.json()


async def _create_task(
    client: AsyncClient,
    *,
    title: str = "Test Task",
    lat: float = 12.9352,
    lon: float = 77.6245,
    min_rating: float = 5.0,
) -> dict:
    resp = await client.post(
        "/api/tasks",
        json={
            "title": title,
            "latitude": lat,
            "longitude": lon,
            "required_min_rating": min_rating,
        },
    )
    assert resp.status_code == 201
    return resp.json()


# ---------------------------------------------------------------------------
# POST /api/tasks
# ---------------------------------------------------------------------------


class TestCreateTask:
    async def test_creates_task(self, client: AsyncClient):
        resp = await client.post(
            "/api/tasks",
            json={
                "title": "Delivery Koramangala",
                "latitude": 12.9352,
                "longitude": 77.6245,
                "required_min_rating": 6.0,
            },
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["title"] == "Delivery Koramangala"
        assert data["assignment_status"] == "Pending"
        assert data["assigned_worker_id"] is None

    async def test_rejects_invalid_latitude(self, client: AsyncClient):
        resp = await client.post(
            "/api/tasks",
            json={"title": "Bad", "latitude": 200.0, "longitude": 77.0,
                  "required_min_rating": 5.0},
        )
        assert resp.status_code == 422

    async def test_rejects_missing_title(self, client: AsyncClient):
        resp = await client.post(
            "/api/tasks",
            json={"latitude": 12.0, "longitude": 77.0, "required_min_rating": 5.0},
        )
        assert resp.status_code == 422


# ---------------------------------------------------------------------------
# GET /api/tasks
# ---------------------------------------------------------------------------


class TestListTasks:
    async def test_empty_initially(self, client: AsyncClient):
        resp = await client.get("/api/tasks")
        assert resp.status_code == 200
        assert resp.json() == []

    async def test_returns_created_tasks(self, client: AsyncClient):
        await _create_task(client, title="T1")
        await _create_task(client, title="T2")
        resp = await client.get("/api/tasks")
        assert len(resp.json()) == 2

    async def test_status_filter(self, client: AsyncClient):
        await _create_task(client, title="Pending Task")
        resp = await client.get("/api/tasks", params={"status": "Pending"})
        assert len(resp.json()) == 1
        resp2 = await client.get("/api/tasks", params={"status": "Assigned"})
        assert len(resp2.json()) == 0


# ---------------------------------------------------------------------------
# GET /api/tasks/{id}
# ---------------------------------------------------------------------------


class TestGetTask:
    async def test_get_existing(self, client: AsyncClient):
        task = await _create_task(client, title="My Task")
        resp = await client.get(f"/api/tasks/{task['id']}")
        assert resp.status_code == 200
        assert resp.json()["id"] == task["id"]

    async def test_404_not_found(self, client: AsyncClient):
        resp = await client.get("/api/tasks/nonexistent-id")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# POST /api/tasks/{id}/assign  (core matching pipeline)
# ---------------------------------------------------------------------------


class TestAssignTask:
    async def test_assigns_nearest_qualified_worker(self, client: AsyncClient):
        # Worker very close, meets rating
        near = await _create_worker(client, name="Near", lat=12.936, lon=77.625, rating=7.0)
        # Worker far away, meets rating
        await _create_worker(client, name="Far", lat=13.5, lon=78.5, rating=9.0)

        task = await _create_task(client, min_rating=6.0)
        resp = await client.post(f"/api/tasks/{task['id']}/assign")
        assert resp.status_code == 200
        data = resp.json()
        assert data["task_id"] == task["id"]
        assert "assigned_worker" in data
        assert data["distance_km"] > 0
        assert data["compound_score"] >= 0
        assert data["candidates_evaluated"] == 2

    async def test_task_status_becomes_assigned(self, client: AsyncClient):
        await _create_worker(client, name="Worker", lat=12.936, lon=77.625, rating=7.0)
        task = await _create_task(client)
        await client.post(f"/api/tasks/{task['id']}/assign")
        resp = await client.get(f"/api/tasks/{task['id']}")
        assert resp.json()["assignment_status"] == "Assigned"

    async def test_worker_becomes_busy_after_assignment(self, client: AsyncClient):
        w = await _create_worker(client, name="Worker", lat=12.936, lon=77.625, rating=7.0)
        task = await _create_task(client)
        await client.post(f"/api/tasks/{task['id']}/assign")
        resp = await client.get(f"/api/workers/{w['id']}")
        assert resp.json()["status"] == "Busy"

    async def test_rejects_below_min_rating(self, client: AsyncClient):
        # Only worker with rating 4.0, but task requires 6.0
        await _create_worker(client, name="Low", lat=12.936, lon=77.625, rating=4.0)
        task = await _create_task(client, min_rating=6.0)
        resp = await client.post(f"/api/tasks/{task['id']}/assign")
        assert resp.status_code == 422

    async def test_rejects_busy_workers(self, client: AsyncClient):
        await _create_worker(
            client, name="Busy", lat=12.936, lon=77.625, rating=8.0, status="Busy"
        )
        task = await _create_task(client, min_rating=5.0)
        resp = await client.post(f"/api/tasks/{task['id']}/assign")
        assert resp.status_code == 422

    async def test_rejects_double_assignment(self, client: AsyncClient):
        await _create_worker(client, name="Worker", lat=12.936, lon=77.625, rating=8.0)
        task = await _create_task(client)
        await client.post(f"/api/tasks/{task['id']}/assign")
        # Second assignment attempt
        resp = await client.post(f"/api/tasks/{task['id']}/assign")
        assert resp.status_code == 409

    async def test_404_for_nonexistent_task(self, client: AsyncClient):
        resp = await client.post("/api/tasks/ghost/assign")
        assert resp.status_code == 404

    async def test_assigned_worker_id_stored(self, client: AsyncClient):
        w = await _create_worker(client, name="Worker", lat=12.936, lon=77.625, rating=7.0)
        task = await _create_task(client)
        await client.post(f"/api/tasks/{task['id']}/assign")
        resp = await client.get(f"/api/tasks/{task['id']}")
        assert resp.json()["assigned_worker_id"] == w["id"]

    async def test_match_metadata_stored(self, client: AsyncClient):
        await _create_worker(client, name="Worker", lat=12.936, lon=77.625, rating=7.0)
        task = await _create_task(client)
        await client.post(f"/api/tasks/{task['id']}/assign")
        resp = await client.get(f"/api/tasks/{task['id']}")
        data = resp.json()
        assert data["matched_worker_distance_km"] is not None
        assert data["matched_worker_score"] is not None

    async def test_correct_worker_selected_by_score(self, client: AsyncClient):
        """Verify the heap picks the worker with the best compound score, not just closest."""
        # Both workers are roughly the same distance but w_high has rating 9.5 vs 6.5
        w_low  = await _create_worker(client, name="LowRating",  lat=12.936, lon=77.625, rating=6.5)
        w_high = await _create_worker(client, name="HighRating", lat=12.937, lon=77.626, rating=9.5)

        task = await _create_task(client, min_rating=6.0)
        resp = await client.post(f"/api/tasks/{task['id']}/assign")
        assert resp.status_code == 200
        # With default weights (0.6 dist / 0.4 rating), nearly identical distances
        # should let the higher rating tip the balance — verify we get a valid worker
        assigned_id = resp.json()["assigned_worker"]["id"]
        assert assigned_id in {w_low["id"], w_high["id"]}


# ---------------------------------------------------------------------------
# GET /api/tasks/{id}/candidates
# ---------------------------------------------------------------------------


class TestCandidates:
    async def test_lists_ranked_candidates(self, client: AsyncClient):
        await _create_worker(client, name="A", lat=12.936, lon=77.625, rating=8.0)
        await _create_worker(client, name="B", lat=13.0, lon=77.7, rating=9.0)
        await _create_worker(client, name="C", lat=12.934, lon=77.624, rating=7.0)
        task = await _create_task(client, min_rating=5.0)

        resp = await client.get(f"/api/tasks/{task['id']}/candidates")
        assert resp.status_code == 200
        candidates = resp.json()
        assert len(candidates) == 3
        # Ranked ascending by compound_score
        scores = [c["compound_score"] for c in candidates]
        assert scores == sorted(scores)

    async def test_does_not_modify_task_status(self, client: AsyncClient):
        await _create_worker(client, name="A", lat=12.936, lon=77.625, rating=8.0)
        task = await _create_task(client)
        await client.get(f"/api/tasks/{task['id']}/candidates")
        # Task must still be Pending
        resp = await client.get(f"/api/tasks/{task['id']}")
        assert resp.json()["assignment_status"] == "Pending"


# ---------------------------------------------------------------------------
# PATCH /api/tasks/{id}/complete
# ---------------------------------------------------------------------------


class TestCompleteTask:
    async def test_complete_assigned_task(self, client: AsyncClient):
        w = await _create_worker(client, name="Worker", lat=12.936, lon=77.625, rating=7.0)
        task = await _create_task(client)
        await client.post(f"/api/tasks/{task['id']}/assign")

        resp = await client.patch(f"/api/tasks/{task['id']}/complete")
        assert resp.status_code == 200
        assert resp.json()["assignment_status"] == "Completed"

    async def test_worker_freed_after_completion(self, client: AsyncClient):
        w = await _create_worker(client, name="Worker", lat=12.936, lon=77.625, rating=7.0)
        task = await _create_task(client)
        await client.post(f"/api/tasks/{task['id']}/assign")
        await client.patch(f"/api/tasks/{task['id']}/complete")

        resp = await client.get(f"/api/workers/{w['id']}")
        assert resp.json()["status"] == "Available"

    async def test_cannot_complete_pending_task(self, client: AsyncClient):
        task = await _create_task(client)
        resp = await client.patch(f"/api/tasks/{task['id']}/complete")
        assert resp.status_code == 409

    async def test_404_for_nonexistent_task(self, client: AsyncClient):
        resp = await client.patch("/api/tasks/ghost/complete")
        assert resp.status_code == 404
