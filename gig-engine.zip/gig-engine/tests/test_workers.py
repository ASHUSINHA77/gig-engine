"""
Integration tests for the /api/workers endpoints.

Uses the in-memory SQLite session from conftest.py — no real PostgreSQL needed.
"""

from __future__ import annotations

import pytest
import pytest_asyncio
from httpx import AsyncClient


pytestmark = pytest.mark.asyncio


# ---------------------------------------------------------------------------
# POST /api/workers
# ---------------------------------------------------------------------------


class TestCreateWorker:
    async def test_creates_worker_successfully(self, client: AsyncClient):
        resp = await client.post(
            "/api/workers",
            json={
                "name": "Alice",
                "latitude": 12.9716,
                "longitude": 77.5946,
                "skill_rating": 8.5,
            },
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "Alice"
        assert data["skill_rating"] == 8.5
        assert data["status"] == "Available"
        assert "id" in data

    async def test_default_status_is_available(self, client: AsyncClient):
        resp = await client.post(
            "/api/workers",
            json={"name": "Bob", "latitude": 12.0, "longitude": 77.0, "skill_rating": 5.0},
        )
        assert resp.status_code == 201
        assert resp.json()["status"] == "Available"

    async def test_explicit_busy_status(self, client: AsyncClient):
        resp = await client.post(
            "/api/workers",
            json={
                "name": "Charlie",
                "latitude": 13.0,
                "longitude": 78.0,
                "skill_rating": 7.0,
                "status": "Busy",
            },
        )
        assert resp.status_code == 201
        assert resp.json()["status"] == "Busy"

    async def test_rejects_invalid_latitude(self, client: AsyncClient):
        resp = await client.post(
            "/api/workers",
            json={"name": "Bad", "latitude": 999.0, "longitude": 77.0, "skill_rating": 5.0},
        )
        assert resp.status_code == 422

    async def test_rejects_skill_rating_above_10(self, client: AsyncClient):
        resp = await client.post(
            "/api/workers",
            json={"name": "Bad", "latitude": 12.0, "longitude": 77.0, "skill_rating": 11.0},
        )
        assert resp.status_code == 422

    async def test_rejects_negative_skill_rating(self, client: AsyncClient):
        resp = await client.post(
            "/api/workers",
            json={"name": "Bad", "latitude": 12.0, "longitude": 77.0, "skill_rating": -1.0},
        )
        assert resp.status_code == 422

    async def test_rejects_missing_name(self, client: AsyncClient):
        resp = await client.post(
            "/api/workers",
            json={"latitude": 12.0, "longitude": 77.0, "skill_rating": 5.0},
        )
        assert resp.status_code == 422


# ---------------------------------------------------------------------------
# GET /api/workers
# ---------------------------------------------------------------------------


class TestListWorkers:
    async def test_empty_list_initially(self, client: AsyncClient):
        resp = await client.get("/api/workers")
        assert resp.status_code == 200
        assert resp.json() == []

    async def test_returns_created_workers(self, client: AsyncClient):
        for name in ("Alice", "Bob", "Charlie"):
            await client.post(
                "/api/workers",
                json={"name": name, "latitude": 12.0, "longitude": 77.0, "skill_rating": 5.0},
            )
        resp = await client.get("/api/workers")
        assert resp.status_code == 200
        assert len(resp.json()) == 3

    async def test_status_filter_available(self, client: AsyncClient):
        await client.post(
            "/api/workers",
            json={"name": "Free", "latitude": 12.0, "longitude": 77.0,
                  "skill_rating": 5.0, "status": "Available"},
        )
        await client.post(
            "/api/workers",
            json={"name": "Taken", "latitude": 12.0, "longitude": 77.0,
                  "skill_rating": 5.0, "status": "Busy"},
        )
        resp = await client.get("/api/workers", params={"status": "Available"})
        assert resp.status_code == 200
        names = [w["name"] for w in resp.json()]
        assert "Free" in names
        assert "Taken" not in names

    async def test_pagination(self, client: AsyncClient):
        for i in range(5):
            await client.post(
                "/api/workers",
                json={"name": f"W{i}", "latitude": 12.0, "longitude": 77.0, "skill_rating": 5.0},
            )
        resp = await client.get("/api/workers", params={"limit": 2, "offset": 0})
        assert len(resp.json()) == 2

        resp2 = await client.get("/api/workers", params={"limit": 2, "offset": 2})
        assert len(resp2.json()) == 2


# ---------------------------------------------------------------------------
# GET /api/workers/{id}
# ---------------------------------------------------------------------------


class TestGetWorker:
    async def test_get_existing_worker(self, client: AsyncClient):
        create = await client.post(
            "/api/workers",
            json={"name": "Dave", "latitude": 12.0, "longitude": 77.0, "skill_rating": 6.0},
        )
        worker_id = create.json()["id"]

        resp = await client.get(f"/api/workers/{worker_id}")
        assert resp.status_code == 200
        assert resp.json()["id"] == worker_id
        assert resp.json()["name"] == "Dave"

    async def test_404_for_nonexistent_worker(self, client: AsyncClient):
        resp = await client.get("/api/workers/does-not-exist")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# PATCH /api/workers/{id}/status
# ---------------------------------------------------------------------------


class TestUpdateWorkerStatus:
    async def test_update_to_busy(self, client: AsyncClient):
        create = await client.post(
            "/api/workers",
            json={"name": "Eve", "latitude": 12.0, "longitude": 77.0, "skill_rating": 7.0},
        )
        worker_id = create.json()["id"]

        resp = await client.patch(
            f"/api/workers/{worker_id}/status", json={"status": "Busy"}
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "Busy"

    async def test_update_back_to_available(self, client: AsyncClient):
        create = await client.post(
            "/api/workers",
            json={"name": "Frank", "latitude": 12.0, "longitude": 77.0,
                  "skill_rating": 7.0, "status": "Busy"},
        )
        worker_id = create.json()["id"]

        resp = await client.patch(
            f"/api/workers/{worker_id}/status", json={"status": "Available"}
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "Available"

    async def test_404_for_nonexistent_worker(self, client: AsyncClient):
        resp = await client.patch(
            "/api/workers/ghost-id/status", json={"status": "Busy"}
        )
        assert resp.status_code == 404

    async def test_invalid_status_rejected(self, client: AsyncClient):
        create = await client.post(
            "/api/workers",
            json={"name": "Grace", "latitude": 12.0, "longitude": 77.0, "skill_rating": 5.0},
        )
        worker_id = create.json()["id"]
        resp = await client.patch(
            f"/api/workers/{worker_id}/status", json={"status": "OnVacation"}
        )
        assert resp.status_code == 422
